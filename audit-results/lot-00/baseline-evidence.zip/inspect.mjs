import {chromium} from '@playwright/test';
import {createApi} from '../../api/server.mjs';
import {spawn} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const out='audit-results/lot-00', allowedOrigins=new Set(),target=createApi({allowedOrigins}),children=[];
await new Promise(r=>target.server.listen(0,'127.0.0.1',r));
async function web(app){const p=spawn(process.execPath,['scripts/web.mjs',app],{env:{...process.env,PORT:'0',DEMO_LOOPBACK:'1',API_URL:`http://127.0.0.1:${target.server.address().port}`},stdio:['ignore','pipe','pipe']});children.push(p);return new Promise((r,j)=>{p.on('error',j);p.stdout.on('data',x=>{const m=String(x).match(/sur (\d+)/);if(m)r(`http://127.0.0.1:${m[1]}`);});});}
let browser;const report={fixture:'historical, fresh in-memory seed, no visual overrides',permissions:[],routes:[],focus:[]};
try{
 const client=await web('client'),admin=await web('admin');allowedOrigins.add(client);allowedOrigins.add(admin);browser=await chromium.launch();report.browser=browser.version();
 const context=await browser.newContext({locale:'fr-FR',timezoneId:'America/Guadeloupe',viewport:{width:390,height:844},deviceScaleFactor:1,reducedMotion:'reduce'});const page=await context.newPage();
 const request=context.request;
 for(const persona of [null,'renter','owner','newcomer','other','employee','admin','finance','super','super2']){
   const origin=['employee','admin','finance','super','super2'].includes(persona)?admin:client;
   if(persona)await request.post(origin+'/api/v1/session',{data:{persona}});
   const responses=[];for(const path of ['/me','/admin/dashboard','/admin/payments','/admin/staff']){const r=await request.get(origin+'/api/v1'+path);responses.push({path,status:r.status()});}
   report.permissions.push({persona:persona||'visitor',surface:origin===client?'client':'admin',responses});
 }
 await context.clearCookies();
 for(const width of [1440,1280,1024,768,430,390,375,320]){
  await page.setViewportSize({width,height:width===1440?900:844});
  for(const path of ['/','/search','/vehicle/v3','/vehicle/v1']){
   await page.goto(client+path);await page.locator(path==='/'?'#explorer-catalogue[aria-busy=false]':path==='/search'?'#search-items[aria-busy=false]':'.vehicle-detail-layout').waitFor();await page.evaluate(()=>document.fonts.ready);
   const data=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth-innerWidth,title:document.querySelector('h1')?.textContent,controls:[...document.querySelectorAll('a,button,input,select,textarea')].filter(e=>e.getClientRects().length&&!e.disabled).map(e=>{const r=e.getBoundingClientRect();return {tag:e.tagName,name:e.getAttribute('aria-label')||e.labels?.[0]?.textContent?.trim()||e.textContent?.trim(),width:Math.round(r.width*10)/10,height:Math.round(r.height*10)/10,tabIndex:e.tabIndex};}),titleBox:(()=>{const r=document.querySelector('h1').getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,fontSize:getComputedStyle(document.querySelector('h1')).fontSize};})()}));
   report.routes.push({path,width,...data});
   if(path==='/vehicle/v1'&&[1440,390,320].includes(width))await page.screenshot({path:`${out}/captures/v1-${width}.png`,fullPage:true});
   if(width===320){await page.keyboard.press('Control+Home');for(let i=0;i<12;i++){await page.keyboard.press('Tab');report.focus.push({path,...await page.evaluate(()=>{const e=document.activeElement,r=e.getBoundingClientRect(),s=getComputedStyle(e);return {name:e.getAttribute('aria-label')||e.textContent?.trim().slice(0,80),tag:e.tagName,outline:s.outline,box:{x:r.x,y:r.y,width:r.width,height:r.height},centerVisible:e.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))};})});}}
  }
 }
 // Native routes after geometry sampling; no read interception or seed edit.
 await page.setViewportSize({width:320,height:844});await page.goto(client+'/vehicle/v1');const open=page.getByRole('button',{name:'Ouvrir la photo 1 de Peugeot 208'});await open.click();await page.getByRole('dialog').waitFor();await page.screenshot({path:out+'/captures/gallery-320.png'});await page.keyboard.press('Escape');report.galleryFocusRestored=await open.evaluate(e=>document.activeElement===e);
 await page.goto(client+'/search?q=zzzzbaseline');await page.getByRole('heading',{name:'Aucun véhicule ici'}).waitFor();await page.screenshot({path:out+'/captures/empty-320.png'});
 await page.route('**/api/v1/**',r=>r.abort());await page.goto(client+'/search');await page.getByRole('heading',{name:'Impossible de charger cette page'}).waitFor();await page.screenshot({path:out+'/captures/error-320.png'});await page.unroute('**/api/v1/**');await page.getByRole('button',{name:'Réessayer'}).click();await page.getByRole('heading',{name:'Résultats',exact:true}).waitFor();report.retry=true;
 await page.setViewportSize({width:1280,height:900});await page.goto(client+'/search');await page.locator('#search-items[aria-busy=false]').waitFor();const cdp=await context.newCDPSession(page);await cdp.send('Emulation.setPageScaleFactor',{pageScaleFactor:2});await page.screenshot({path:out+'/captures/pinch-scale-2.png'});report.zoomLimit='CDP pinch scale 2 recorded; not equivalent to desktop browser 200% zoom, not certified';
 await context.close();
}finally{if(browser)await browser.close();for(const p of children)p.kill();await new Promise(r=>target.server.close(r));writeFileSync(out+'/inspection.json',JSON.stringify(report,null,2));}
