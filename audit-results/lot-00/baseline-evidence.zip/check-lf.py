import io,zipfile,subprocess,pathlib,os,json
root=pathlib.Path('audit-results/lot-00'); target=root/'source-lf'
archive=subprocess.run(['git','archive','--format=zip','HEAD'],capture_output=True,check=True).stdout
with zipfile.ZipFile(io.BytesIO(archive)) as z:z.extractall(target)
for file in target.rglob('*'):
    if file.is_file() and file.suffix in ['.md','.mjs','.js','.json','.css','.html','.yml','.yaml','.py','.csv','.txt']:
        data=file.read_bytes();file.write_bytes(data.replace(b'\r\n',b'\n'))
env=os.environ.copy() # Select Node 24 in PATH before running this Windows reproduction helper.
p=subprocess.run(['cmd','/c','npm.cmd','run','check'],cwd=target,env=env,capture_output=True)
(root/'npm-check-source-lf.log').write_bytes(p.stdout+p.stderr)
print(json.dumps({'command':'npm run check','source':'git archive HEAD, LF blobs, isolated ignored directory','exit':p.returncode}))
