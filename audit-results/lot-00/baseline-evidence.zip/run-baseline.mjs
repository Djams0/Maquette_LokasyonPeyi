import {spawn} from 'node:child_process';
import {openSync,closeSync,writeFileSync,mkdtempSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const out='audit-results/lot-00', results=[], children=[];
const env={...process.env,DEMO_LOOPBACK:'1',DATA_FILE:join(mkdtempSync(join(tmpdir(),'lp-baseline-')),'mock.json')};
writeFileSync(out+'/environment.json',JSON.stringify({node:process.version,seed:'historical api/seed.mjs',persistentDataTouched:false,ports:[3001,8080,8081],dataFile:env.DATA_FILE},null,2));
function start(args,name,extra={}) {const log=openSync(`${out}/${name}.log`,'w'); const p=spawn(process.execPath,args,{env:{...env,...extra},stdio:['ignore',log,log]}); closeSync(log); children.push(p);return p;}
async function run(args,name){const begin=new Date();console.log('START '+name);const p=start(args,name);const code=await new Promise((r,j)=>{p.on('error',j);p.on('exit',r)});results.push({name,args,code,started:begin.toISOString(),ended:new Date().toISOString()});writeFileSync(out+'/commands.json',JSON.stringify(results,null,2));console.log('END '+name+' '+code);return code;}
try {
  await run(['scripts/check.mjs'],'check-syntax');
  await run(['scripts/audit-docs.mjs','--check'],'check-docs');
  await run(['--test',...['api','audit','booking','explorer','message-state','navigation','owner-state','search','vehicle'].map(n=>`tests/${n}.test.mjs`)],'npm-test');
  for(const [args,name] of [[['api/server.mjs'],'api'],[['scripts/web.mjs','client'],'client'],[['scripts/web.mjs','admin'],'admin']])start(args,name);
  for(let i=0;i<100;i++){try{const rs=await Promise.all([3001,8080,8081].map(p=>fetch(`http://127.0.0.1:${p}/health`)));if(rs.every(r=>r.ok))break;}catch{}await new Promise(r=>setTimeout(r,100));}
  await run(['scripts/smoke.mjs'],'smoke');
  await run(['LOKASYON_PEYI_DESIGN_HANDOFF/tools/capture-v32.mjs','app','http://127.0.0.1:8080',out+'/captures'],'captures');
  await run(['node_modules/@playwright/test/cli.js','test'],'playwright');
  await run(['node_modules/@playwright/test/cli.js','test','--config=playwright.audit.config.js','--grep','UI-AUD-0[1-4]'],'playwright-audit');
} finally {for(const p of children)if(p.exitCode===null)p.kill();}
