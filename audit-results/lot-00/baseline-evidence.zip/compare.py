from pathlib import Path
from PIL import Image, ImageChops
import json, subprocess
root=Path('audit-results/lot-00'); caps=root/'captures'
native=Path('LOKASYON_PEYI_DESIGN_HANDOFF/04_VISUAL_REFERENCES/maquettes')
mapping={'accueil-1440':'Accueil_Desktop_Premier_Ecran.png','accueil-390':'Accueil_Mobile_Premier_Ecran.png','catalogue-1440':'Catalogue_Desktop.png','catalogue-390':'Catalogue_Mobile.png','fiche-1440':'Fiche_Desktop.png','fiche-390':'Fiche_Mobile.png'}
results=[]
for key,filename in mapping.items():
    ref=native/filename; app=caps/f'app-{key}-viewport.png'; a=Image.open(ref).convert('RGB'); b=Image.open(app).convert('RGB'); w=min(a.width,b.width);h=min(a.height,b.height)
    command=['python','LOKASYON_PEYI_DESIGN_HANDOFF/tools/compare_v32.py',str(ref),str(app),str(root/'comparisons'/key),'--box','0','0',str(w),str(h)]
    p=subprocess.run(command,capture_output=True,text=True)
    diff=ImageChops.difference(a.crop((0,0,w,h)),b.crop((0,0,w,h)));hist=ImageChops.lighter(ImageChops.lighter(*diff.split()[:2]),diff.split()[2]).histogram()
    results.append({'key':key,'reference':str(ref),'kind':'native','referenceSize':a.size,'actualFullSize':Image.open(caps/f'app-{key}-full.png').size,'crop':[0,0,w,h],'differentPixelPercent':round((w*h-hist[0])*100/(w*h),2),'command':command,'exit':p.returncode,'stdout':p.stdout})
for key in ['accueil-320','catalogue-320','fiche-320']:
    ref=caps/f'reference-{key}-viewport.png';app=caps/f'app-{key}-viewport.png'
    p=subprocess.run(['python','LOKASYON_PEYI_DESIGN_HANDOFF/tools/compare_v32.py',str(ref),str(app),str(root/'comparisons'/key)],capture_output=True,text=True)
    results.append({'key':key,'kind':'derived HTML','exit':p.returncode,'stdout':p.stdout})
(root/'comparison-metrics.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(results,ensure_ascii=False,indent=2))
