import {chromium} from '@playwright/test';
import {writeFileSync} from 'node:fs';
const b=await chromium.launch(),p=await b.newPage({viewport:{width:390,height:844},locale:'fr-FR',timezoneId:'America/Guadeloupe'}),results=[];
try{for(const path of ['/','/search','/vehicle/v3']){
await p.goto('http://127.0.0.1:8080'+path);await p.locator('h1').waitFor();await p.evaluate(()=>document.fonts.ready);
results.push({path,samples:await p.evaluate(()=>{
 const rgb=s=>(s.match(/[\d.]+/g)||[]).map(Number), lum=c=>c.slice(0,3).map(x=>{x/=255;return x<=.04045?x/12.92:((x+.055)/1.055)**2.4}).reduce((a,x,i)=>a+x*[.2126,.7152,.0722][i],0);
 return [...document.querySelectorAll('main h1, main h2,main label,main button,main p,main a,main span,header a,footer a')].filter(e=>e.getClientRects().length&&[...e.childNodes].some(n=>n.nodeType===3&&n.textContent.trim())).slice(0,70).map(e=>{
 const s=getComputedStyle(e),fg=rgb(s.color);let bg=[255,255,255],complex=false,chain=[];for(let n=e;n;n=n.parentElement)chain.unshift(n);
 for(const n of chain){const t=getComputedStyle(n),c=rgb(t.backgroundColor);if(t.backgroundImage!=='none'||Number(t.opacity)<1)complex=true;const a=c.length===4?c[3]:1;bg=bg.map((v,i)=>v*(1-a)+(c[i]||0)*a);}
 const l1=lum(fg),l2=lum(bg),ratio=(Math.max(l1,l2)+.05)/(Math.min(l1,l2)+.05),large=parseFloat(s.fontSize)>=24||(parseFloat(s.fontSize)>=18.66&&Number(s.fontWeight)>=700);
 return {text:e.textContent.trim().slice(0,80),fg:s.color,bg,ratio:Math.round(ratio*100)/100,threshold:large?3:4.5,complex,passesSample:ratio>=(large?3:4.5)};
 });
})});}
await p.goto('http://127.0.0.1:8080/');await p.keyboard.press('Tab');await p.screenshot({path:'audit-results/lot-00/captures/keyboard-focus-390.png'});
writeFileSync('audit-results/lot-00/contrast.json',JSON.stringify({method:'computed text foreground over composited CSS backgrounds; gradients/images/opacity flagged complex; sample only; not full WCAG audit',results},null,2));
}finally{await b.close();}
